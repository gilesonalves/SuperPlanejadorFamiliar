import { useState, useEffect, useCallback } from "react";
import type { 
  ShoppingState, 
  ShoppingList, 
  ShoppingItem, 
  ShoppingCategory,
  FilterStatus,
  SortBy 
} from "@/services/shopping/types";
import { 
  loadShopping, 
  saveShopping, 
  canCreateList, 
  canAddItem,
  getTotalItems,
  FREE_LIMITS 
} from "@/services/shopping/storage";
import { defaultCategories } from "@/services/shopping/seed";

export function useShopping() {
  const [state, setState] = useState<ShoppingState>(loadShopping);
  const [showProGate, setShowProGate] = useState(false);

  const saveState = useCallback((newState: ShoppingState) => {
    setState(newState);
    saveShopping(newState);
  }, []);

  const activeList = state.listas.find(l => l.id === state.listaAtivaId);

  // CRUD de Listas
  const createList = useCallback((nome: string) => {
    if (!canCreateList(state)) {
      setShowProGate(true);
      return;
    }

    const newList: ShoppingList = {
      id: crypto.randomUUID(),
      nome,
      categorias: defaultCategories,
      itens: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    const newState = {
      ...state,
      listas: [...state.listas, newList],
      listaAtivaId: newList.id,
    };
    saveState(newState);
  }, [state, saveState]);

  const updateList = useCallback((listId: string, updates: Partial<ShoppingList>) => {
    const newState = {
      ...state,
      listas: state.listas.map(lista =>
        lista.id === listId
          ? { ...lista, ...updates, updatedAt: Date.now() }
          : lista
      ),
    };
    saveState(newState);
  }, [state, saveState]);

  const duplicateList = useCallback((listId: string) => {
    if (!canCreateList(state)) {
      setShowProGate(true);
      return;
    }

    const originalList = state.listas.find(l => l.id === listId);
    if (!originalList) return;

    const newList: ShoppingList = {
      ...originalList,
      id: crypto.randomUUID(),
      nome: `${originalList.nome} (Cópia)`,
      itens: originalList.itens.map(item => ({
        ...item,
        id: crypto.randomUUID(),
        status: "pendente" as const,
      })),
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    const newState = {
      ...state,
      listas: [...state.listas, newList],
      listaAtivaId: newList.id,
    };
    saveState(newState);
  }, [state, saveState]);

  const setActiveList = useCallback((listId: string) => {
    const newState = { ...state, listaAtivaId: listId };
    saveState(newState);
  }, [state, saveState]);

  const archiveList = useCallback((listId: string) => {
    updateList(listId, { arquivada: true });
  }, [updateList]);

  // CRUD de Itens
  const addItem = useCallback((item: Omit<ShoppingItem, "id">) => {
    if (!canAddItem(state)) {
      setShowProGate(true);
      return;
    }

    if (!activeList) return;

    const newItem: ShoppingItem = {
      ...item,
      id: crypto.randomUUID(),
    };

    updateList(activeList.id, {
      itens: [...activeList.itens, newItem],
    });
  }, [activeList, state, updateList]);

  const updateItem = useCallback((itemId: string, updates: Partial<ShoppingItem>) => {
    if (!activeList) return;

    updateList(activeList.id, {
      itens: activeList.itens.map(item =>
        item.id === itemId ? { ...item, ...updates } : item
      ),
    });
  }, [activeList, updateList]);

  const removeItem = useCallback((itemId: string) => {
    if (!activeList) return;

    updateList(activeList.id, {
      itens: activeList.itens.filter(item => item.id !== itemId),
    });
  }, [activeList, updateList]);

  const toggleItemStatus = useCallback((itemId: string) => {
    if (!activeList) return;

    const item = activeList.itens.find(i => i.id === itemId);
    if (!item) return;

    let newStatus: ShoppingItem["status"];
    switch (item.status) {
      case "pendente":
        newStatus = "carrinho";
        break;
      case "carrinho":
        newStatus = "comprado";
        break;
      case "comprado":
        newStatus = "pendente";
        break;
    }

    updateItem(itemId, { status: newStatus });
  }, [activeList, updateItem]);

  // Ações em massa
  const markAllAs = useCallback((status: ShoppingItem["status"]) => {
    if (!activeList) return;

    updateList(activeList.id, {
      itens: activeList.itens.map(item => ({ ...item, status })),
    });
  }, [activeList, updateList]);

  const clearCart = useCallback(() => {
    if (!activeList) return;

    updateList(activeList.id, {
      itens: activeList.itens.map(item =>
        item.status === "carrinho" ? { ...item, status: "pendente" } : item
      ),
    });
  }, [activeList, updateList]);

  // Cálculos
  const getTotalByCategory = useCallback((categoriaId: string) => {
    if (!activeList) return 0;
    
    return activeList.itens
      .filter(item => item.categoriaId === categoriaId)
      .reduce((total, item) => {
        const preco = item.preco || 0;
        const quantidade = item.quantidade || 0;
        return total + (preco * quantidade);
      }, 0);
  }, [activeList]);

  const getTotalGeral = useCallback(() => {
    if (!activeList) return 0;
    
    return activeList.itens.reduce((total, item) => {
      const preco = item.preco || 0;
      const quantidade = item.quantidade || 0;
      return total + (preco * quantidade);
    }, 0);
  }, [activeList]);

  const getStats = useCallback(() => {
    if (!activeList) return { total: 0, pendentes: 0, carrinho: 0, comprados: 0 };

    const stats = activeList.itens.reduce(
      (acc, item) => {
        acc.total++;
        acc[item.status]++;
        return acc;
      },
      { total: 0, pendentes: 0, carrinho: 0, comprados: 0 }
    );

    return stats;
  }, [activeList]);

  // Gate do plano
  const limits = {
    canCreateList: canCreateList(state),
    canAddItem: canAddItem(state),
    currentLists: state.listas.filter(l => !l.arquivada).length,
    currentItems: getTotalItems(state),
    maxLists: FREE_LIMITS.maxLists,
    maxItems: FREE_LIMITS.maxItems,
  };

  return {
    // State
    state,
    activeList,
    showProGate,
    setShowProGate,
    
    // Lista operations
    createList,
    updateList,
    duplicateList,
    setActiveList,
    archiveList,
    
    // Item operations
    addItem,
    updateItem,
    removeItem,
    toggleItemStatus,
    
    // Bulk operations
    markAllAs,
    clearCart,
    
    // Calculations
    getTotalByCategory,
    getTotalGeral,
    getStats,
    
    // Limits
    limits,
  };
}