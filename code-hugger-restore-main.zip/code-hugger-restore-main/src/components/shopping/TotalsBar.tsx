import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ShoppingCategory } from "@/services/shopping/types";
import { useShopping } from "@/hooks/useShopping";
import * as LucideIcons from "lucide-react";

interface TotalsBarProps {
  categories: ShoppingCategory[];
}

export function TotalsBar({ categories }: TotalsBarProps) {
  const { getTotalByCategory, getTotalGeral, getStats } = useShopping();
  
  const stats = getStats();
  const totalGeral = getTotalGeral();

  const getIcon = (iconName?: string) => {
    if (!iconName) return null;
    
    const IconComponent = (LucideIcons as any)[iconName];
    if (IconComponent) {
      return <IconComponent className="h-3 w-3" />;
    }
    return null;
  };

  // Categorias com valores > 0
  const categoriesWithValues = categories
    .map(category => ({
      ...category,
      total: getTotalByCategory(category.id)
    }))
    .filter(category => category.total > 0)
    .sort((a, b) => b.total - a.total);

  return (
    <Card className="sticky bottom-0 bg-background/95 backdrop-blur border-t-2 border-primary/20">
      <CardContent className="p-4">
        <div className="space-y-3">
          {/* Estatísticas de itens */}
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <span className="text-muted-foreground">Itens:</span>
              <Badge variant="outline">{stats.total} total</Badge>
              {stats.pendentes > 0 && (
                <Badge variant="default">{stats.pendentes} pendentes</Badge>
              )}
              {stats.carrinho > 0 && (
                <Badge variant="secondary">{stats.carrinho} no carrinho</Badge>
              )}
              {stats.comprados > 0 && (
                <Badge variant="outline">{stats.comprados} comprados</Badge>
              )}
            </div>
          </div>

          <Separator />

          {/* Totais por categoria */}
          {categoriesWithValues.length > 0 && (
            <div className="space-y-2">
              <span className="text-sm font-medium text-muted-foreground">
                Totais por categoria:
              </span>
              <div className="flex flex-wrap gap-2">
                {categoriesWithValues.map((category) => (
                  <Badge key={category.id} variant="outline" className="text-xs">
                    <div className="flex items-center gap-1">
                      {getIcon(category.icon)}
                      <span>{category.nome}</span>
                      <span className="font-semibold">
                        {category.total.toLocaleString("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                          minimumFractionDigits: 0,
                          maximumFractionDigits: 0,
                        })}
                      </span>
                    </div>
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {/* Total geral */}
          <div className="flex items-center justify-between">
            <span className="text-lg font-semibold">Total Geral:</span>
            <span className="text-2xl font-bold text-primary">
              {totalGeral.toLocaleString("pt-BR", {
                style: "currency",
                currency: "BRL",
              })}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}