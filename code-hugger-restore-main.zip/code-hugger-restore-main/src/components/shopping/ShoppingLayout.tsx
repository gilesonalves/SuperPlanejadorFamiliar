import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { FilterStatus, SortBy } from "@/services/shopping/types";
import { useShopping } from "@/hooks/useShopping";
import { ListPicker } from "./ListPicker";
import { CategoryChips } from "./CategoryChips";
import { ItemEditor } from "./ItemEditor";
import { ItemsTable } from "./ItemsTable";
import { TotalsBar } from "./TotalsBar";
import { ProGateModal } from "./ProGateModal";
import { RotateCcw, CheckCircle } from "lucide-react";

export function ShoppingLayout() {
  const { 
    activeList, 
    markAllAs, 
    clearCart, 
    showProGate, 
    setShowProGate,
    limits 
  } = useShopping();

  const [statusFilter, setStatusFilter] = useState<FilterStatus>("todos");
  const [categoryFilter, setCategoryFilter] = useState<string | undefined>();
  const [sortBy, setSortBy] = useState<SortBy>("nome");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  if (!activeList) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold mb-4">Lista de Compras</h2>
          <p className="text-muted-foreground mb-6">
            Crie sua primeira lista para começar a organizar suas compras.
          </p>
          <ListPicker />
        </div>
      </div>
    );
  }

  const handleSortChange = (newSortBy: SortBy, direction: "asc" | "desc") => {
    setSortBy(newSortBy);
    setSortDirection(direction);
  };

  return (
    <div className="container mx-auto p-6 space-y-6 pb-32">
      {/* Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Lista de Compras</h1>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => markAllAs("carrinho")}
              disabled={activeList.itens.length === 0}
            >
              <CheckCircle className="h-4 w-4 mr-1" />
              Marcar Tudo
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={clearCart}
              disabled={!activeList.itens.some(i => i.status === "carrinho")}
            >
              <RotateCcw className="h-4 w-4 mr-1" />
              Limpar Carrinho
            </Button>
          </div>
        </div>

        <ListPicker />
      </div>

      <Separator />

      {/* Filtros */}
      <CategoryChips
        categories={activeList.categorias}
        selectedCategory={categoryFilter}
        onCategoryChange={setCategoryFilter}
        statusFilter={statusFilter}
        onStatusChange={setStatusFilter}
      />

      <Separator />

      {/* Editor de Item */}
      <ItemEditor
        categories={activeList.categorias}
      />

      <Separator />

      {/* Tabela de Itens */}
      <ItemsTable
        items={activeList.itens}
        categories={activeList.categorias}
        statusFilter={statusFilter}
        categoryFilter={categoryFilter}
        sortBy={sortBy}
        sortDirection={sortDirection}
        onSortChange={handleSortChange}
      />

      {/* Totais */}
      <TotalsBar categories={activeList.categorias} />

      {/* Modal de upgrade */}
      <ProGateModal
        open={showProGate}
        onOpenChange={setShowProGate}
        feature={limits.canCreateList ? "item" : "lista"}
        currentCount={limits.canCreateList ? limits.currentItems : limits.currentLists}
        maxCount={limits.canCreateList ? limits.maxItems : limits.maxLists}
      />
    </div>
  );
}