import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Crown, Plus } from "lucide-react";
import { ShoppingItem, ShoppingCategory } from "@/services/shopping/types";
import { useShopping } from "@/hooks/useShopping";

interface ItemEditorProps {
  categories: ShoppingCategory[];
  onItemAdded?: () => void;
  editingItem?: ShoppingItem;
  onEditComplete?: () => void;
}

export function ItemEditor({ categories, onItemAdded, editingItem, onEditComplete }: ItemEditorProps) {
  const { addItem, updateItem, limits } = useShopping();
  
  const [formData, setFormData] = useState<Partial<ShoppingItem>>(() => 
    editingItem || {
      nome: "",
      categoriaId: "",
      quantidade: 1,
      unidade: "un",
      preco: undefined,
      marca: "",
      observacao: "",
      status: "pendente",
    }
  );

  const isEditing = !!editingItem;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.nome?.trim() || !formData.categoriaId) return;

    if (isEditing && editingItem) {
      updateItem(editingItem.id, formData);
      onEditComplete?.();
    } else {
      if (!limits.canAddItem) return;
      
      addItem({
        nome: formData.nome.trim(),
        categoriaId: formData.categoriaId,
        quantidade: formData.quantidade || 1,
        unidade: formData.unidade || "un",
        preco: formData.preco || undefined,
        marca: formData.marca?.trim() || undefined,
        observacao: formData.observacao?.trim() || undefined,
        status: "pendente",
      });
      
      // Reset form
      setFormData({
        nome: "",
        categoriaId: formData.categoriaId, // Manter categoria selecionada
        quantidade: 1,
        unidade: "un",
        preco: undefined,
        marca: "",
        observacao: "",
        status: "pendente",
      });
      
      onItemAdded?.();
    }
  };

  const handleQuickAdd = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (formData.nome?.trim()) {
        handleSubmit(e as any);
      }
    }
  };

  const unidades = ["un", "kg", "g", "ml", "l", "pct", "cx"];

  return (
    <form onSubmit={handleSubmit} className="space-y-4 p-4 border rounded-lg bg-muted/30">
      <div className="flex items-center gap-2">
        <h3 className="font-medium">
          {isEditing ? "Editar Item" : "Adicionar Item"}
        </h3>
        {!limits.canAddItem && !isEditing && (
          <Badge variant="outline" className="text-xs">
            <Crown className="h-3 w-3 mr-1" />
            Limite atingido
          </Badge>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Nome (obrigatório) */}
        <div className="md:col-span-2 lg:col-span-1">
          <Input
            placeholder="Nome do item *"
            value={formData.nome || ""}
            onChange={(e) => setFormData(prev => ({ ...prev, nome: e.target.value }))}
            onKeyDown={handleQuickAdd}
            className="font-medium"
            autoFocus={!isEditing}
          />
        </div>

        {/* Categoria (obrigatória) */}
        <div>
          <Select 
            value={formData.categoriaId || ""} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, categoriaId: value }))}
          >
            <SelectTrigger>
              <SelectValue placeholder="Categoria *" />
            </SelectTrigger>
            <SelectContent>
              {categories
                .sort((a, b) => a.ordem - b.ordem)
                .map((cat) => (
                  <SelectItem key={cat.id} value={cat.id}>
                    {cat.nome}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>

        {/* Quantidade e Unidade */}
        <div className="flex gap-2">
          <Input
            type="number"
            placeholder="Qtd"
            value={formData.quantidade || ""}
            onChange={(e) => setFormData(prev => ({ 
              ...prev, 
              quantidade: parseFloat(e.target.value) || 1 
            }))}
            className="w-20"
            min="0.1"
            step="0.1"
          />
          <Select 
            value={formData.unidade || "un"} 
            onValueChange={(value) => setFormData(prev => ({ ...prev, unidade: value as any }))}
          >
            <SelectTrigger className="w-20">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {unidades.map((unidade) => (
                <SelectItem key={unidade} value={unidade}>
                  {unidade}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Preço */}
        <div>
          <Input
            type="number"
            placeholder="Preço (R$)"
            value={formData.preco || ""}
            onChange={(e) => setFormData(prev => ({ 
              ...prev, 
              preco: parseFloat(e.target.value) || undefined 
            }))}
            min="0"
            step="0.01"
          />
        </div>

        {/* Marca */}
        <div>
          <Input
            placeholder="Marca (opcional)"
            value={formData.marca || ""}
            onChange={(e) => setFormData(prev => ({ ...prev, marca: e.target.value }))}
          />
        </div>
      </div>

      {/* Observações */}
      <div>
        <Textarea
          placeholder="Observações, dicas de receita, informações nutricionais..."
          value={formData.observacao || ""}
          onChange={(e) => setFormData(prev => ({ ...prev, observacao: e.target.value }))}
          rows={2}
          className="text-sm"
        />
      </div>

      {/* Botões */}
      <div className="flex gap-2">
        {isEditing ? (
          <>
            <Button type="submit" className="flex-1">
              Salvar Alterações
            </Button>
            <Button 
              type="button" 
              variant="outline" 
              onClick={onEditComplete}
            >
              Cancelar
            </Button>
          </>
        ) : (
          <Button 
            type="submit" 
            disabled={!formData.nome?.trim() || !formData.categoriaId || !limits.canAddItem}
            className="w-full"
          >
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Item
            {!limits.canAddItem && (
              <Crown className="h-3 w-3 ml-2" />
            )}
          </Button>
        )}
      </div>

      <div className="text-xs text-muted-foreground">
        <strong>Dica:</strong> Pressione Enter no nome para adicionar rapidamente
      </div>
    </form>
  );
}