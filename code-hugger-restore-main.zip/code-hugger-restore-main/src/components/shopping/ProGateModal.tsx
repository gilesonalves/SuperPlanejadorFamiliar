import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Crown, Check } from "lucide-react";

interface ProGateModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  feature: "lista" | "item";
  currentCount?: number;
  maxCount?: number;
}

export function ProGateModal({ open, onOpenChange, feature, currentCount, maxCount }: ProGateModalProps) {
  const openUpgrade = () => {
    alert("Funcionalidade PRO em breve! Por enquanto, aproveite o plano gratuito.");
    onOpenChange(false);
  };

  const featureText = feature === "lista" ? "lista" : "item";
  const featurePlural = feature === "lista" ? "listas" : "itens";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Crown className="h-5 w-5 text-primary" />
            Recurso PRO
            <Badge variant="secondary" className="ml-auto">
              Upgrade
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Você atingiu o limite do plano gratuito para {featurePlural}.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-muted/50 rounded-lg p-4">
            <h4 className="font-medium mb-2">Plano Atual - Gratuito</h4>
            <div className="text-sm text-muted-foreground space-y-1">
              <div>• Máximo 1 lista ativa</div>
              <div>• Até 100 itens no total</div>
              {currentCount && maxCount && (
                <div className="mt-2 text-xs">
                  Atualmente: {currentCount}/{maxCount} {featurePlural}
                </div>
              )}
            </div>
          </div>

          <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
            <h4 className="font-medium mb-2 flex items-center gap-2">
              <Crown className="h-4 w-4 text-primary" />
              Plano PRO
            </h4>
            <div className="text-sm space-y-1">
              <div className="flex items-center gap-2">
                <Check className="h-3 w-3 text-primary" />
                Listas ilimitadas
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-3 w-3 text-primary" />
                Itens ilimitados
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-3 w-3 text-primary" />
                Sincronização na nuvem
              </div>
              <div className="flex items-center gap-2">
                <Check className="h-3 w-3 text-primary" />
                Backup automático
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)} className="flex-1">
              Continuar Gratuito
            </Button>
            <Button onClick={openUpgrade} className="flex-1">
              <Crown className="h-4 w-4 mr-2" />
              Fazer Upgrade
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}