import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ShoppingCategory, FilterStatus } from "@/services/shopping/types";
import { useShopping } from "@/hooks/useShopping";
import * as LucideIcons from "lucide-react";

interface CategoryChipsProps {
  categories: ShoppingCategory[];
  selectedCategory?: string;
  onCategoryChange: (categoryId?: string) => void;
  statusFilter: FilterStatus;
  onStatusChange: (status: FilterStatus) => void;
}

export function CategoryChips({ 
  categories, 
  selectedCategory, 
  onCategoryChange,
  statusFilter,
  onStatusChange 
}: CategoryChipsProps) {
  const { getTotalByCategory } = useShopping();

  const getIcon = (iconName?: string) => {
    if (!iconName) return null;
    
    const IconComponent = (LucideIcons as any)[iconName];
    if (IconComponent) {
      return <IconComponent className="h-3 w-3" />;
    }
    return null;
  };

  const statusOptions: { value: FilterStatus; label: string }[] = [
    { value: "todos", label: "Todos" },
    { value: "pendente", label: "Pendentes" },
    { value: "carrinho", label: "Carrinho" },
    { value: "comprado", label: "Comprados" },
  ];

  return (
    <div className="space-y-3">
      {/* Filtros de Status */}
      <div className="flex flex-wrap gap-2">
        <span className="text-sm font-medium text-muted-foreground">Status:</span>
        {statusOptions.map((option) => (
          <Button
            key={option.value}
            variant={statusFilter === option.value ? "default" : "outline"}
            size="sm"
            onClick={() => onStatusChange(option.value)}
            className="h-7"
          >
            {option.label}
          </Button>
        ))}
      </div>

      {/* Filtros de Categoria */}
      <div className="flex flex-wrap gap-2">
        <span className="text-sm font-medium text-muted-foreground">Categoria:</span>
        
        <Button
          variant={!selectedCategory ? "default" : "outline"}
          size="sm"
          onClick={() => onCategoryChange(undefined)}
          className="h-7"
        >
          Todas
        </Button>

        {categories
          .sort((a, b) => a.ordem - b.ordem)
          .map((category) => {
            const total = getTotalByCategory(category.id);
            const isSelected = selectedCategory === category.id;
            
            return (
              <Button
                key={category.id}
                variant={isSelected ? "default" : "outline"}
                size="sm"
                onClick={() => onCategoryChange(category.id)}
                className="h-7 relative"
              >
                <div className="flex items-center gap-1">
                  {getIcon(category.icon)}
                  <span>{category.nome}</span>
                  {total > 0 && (
                    <Badge 
                      variant="secondary" 
                      className="ml-1 text-xs h-4 px-1"
                    >
                      {total.toLocaleString("pt-BR", {
                        style: "currency",
                        currency: "BRL",
                        minimumFractionDigits: 0,
                        maximumFractionDigits: 0,
                      })}
                    </Badge>
                  )}
                </div>
              </Button>
            );
          })}
      </div>
    </div>
  );
}