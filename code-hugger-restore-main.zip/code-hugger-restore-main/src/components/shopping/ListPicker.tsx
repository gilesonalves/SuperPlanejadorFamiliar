import { useState } from "react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Copy, Archive, Crown } from "lucide-react";
import { useShopping } from "@/hooks/useShopping";

export function ListPicker() {
  const { 
    state, 
    activeList, 
    createList, 
    duplicateList, 
    archiveList, 
    setActiveList,
    limits 
  } = useShopping();
  
  const [showNewListDialog, setShowNewListDialog] = useState(false);
  const [newListName, setNewListName] = useState("");

  const activeLists = state.listas.filter(l => !l.arquivada);

  const handleCreateList = () => {
    if (newListName.trim()) {
      createList(newListName.trim());
      setNewListName("");
      setShowNewListDialog(false);
    }
  };

  const handleDuplicateActive = () => {
    if (activeList) {
      duplicateList(activeList.id);
    }
  };

  const handleArchiveActive = () => {
    if (activeList && activeLists.length > 1) {
      archiveList(activeList.id);
      // Selecionar a primeira lista disponível
      const remaining = activeLists.filter(l => l.id !== activeList.id);
      if (remaining.length > 0) {
        setActiveList(remaining[0].id);
      }
    }
  };

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Select value={activeList?.id || ""} onValueChange={setActiveList}>
        <SelectTrigger className="w-[200px]">
          <SelectValue placeholder="Selecione uma lista" />
        </SelectTrigger>
        <SelectContent>
          {activeLists.map((lista) => (
            <SelectItem key={lista.id} value={lista.id}>
              <div className="flex items-center justify-between w-full">
                <span>{lista.nome}</span>
                <Badge variant="secondary" className="ml-2 text-xs">
                  {lista.itens.length}
                </Badge>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Dialog open={showNewListDialog} onOpenChange={setShowNewListDialog}>
        <DialogTrigger asChild>
          <Button 
            variant="outline" 
            size="sm"
            disabled={!limits.canCreateList}
            className="relative"
          >
            <Plus className="h-4 w-4 mr-1" />
            Nova Lista
            {!limits.canCreateList && (
              <Crown className="h-3 w-3 ml-1 text-primary" />
            )}
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Criar Nova Lista</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Nome da lista"
              value={newListName}
              onChange={(e) => setNewListName(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleCreateList()}
              autoFocus
            />
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                onClick={() => setShowNewListDialog(false)}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button 
                onClick={handleCreateList}
                disabled={!newListName.trim()}
                className="flex-1"
              >
                Criar Lista
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {activeList && (
        <>
          <Button 
            variant="outline" 
            size="sm"
            onClick={handleDuplicateActive}
            disabled={!limits.canCreateList}
            className="relative"
          >
            <Copy className="h-4 w-4 mr-1" />
            Duplicar
            {!limits.canCreateList && (
              <Crown className="h-3 w-3 ml-1 text-primary" />
            )}
          </Button>

          {activeLists.length > 1 && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleArchiveActive}
            >
              <Archive className="h-4 w-4 mr-1" />
              Arquivar
            </Button>
          )}
        </>
      )}

      {state.plan === "free" && (
        <Badge variant="outline" className="text-xs">
          {limits.currentLists}/{limits.maxLists} listas • {limits.currentItems}/{limits.maxItems} itens
        </Badge>
      )}
    </div>
  );
}