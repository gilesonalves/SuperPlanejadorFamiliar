import { useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  HoverCard, 
  HoverCardContent, 
  HoverCardTrigger 
} from "@/components/ui/hover-card";
import { Edit2, Trash2, Info } from "lucide-react";
import * as LucideIcons from "lucide-react";
import { ShoppingItem, ShoppingCategory, FilterStatus, SortBy } from "@/services/shopping/types";
import { useShopping } from "@/hooks/useShopping";
import { ItemEditor } from "./ItemEditor";

interface ItemsTableProps {
  items: ShoppingItem[];
  categories: ShoppingCategory[];
  statusFilter: FilterStatus;
  categoryFilter?: string;
  sortBy: SortBy;
  sortDirection: "asc" | "desc";
  onSortChange: (sortBy: SortBy, direction: "asc" | "desc") => void;
}

export function ItemsTable({ 
  items, 
  categories, 
  statusFilter, 
  categoryFilter, 
  sortBy, 
  sortDirection,
  onSortChange 
}: ItemsTableProps) {
  const { toggleItemStatus, removeItem } = useShopping();
  const [editingItem, setEditingItem] = useState<ShoppingItem | null>(null);

  const getIcon = (iconName?: string) => {
    if (!iconName) return null;
    
    const IconComponent = (LucideIcons as any)[iconName];
    if (IconComponent) {
      return <IconComponent className="h-4 w-4" />;
    }
    return <span className="text-sm">{iconName}</span>; // Fallback emoji
  };

  const getCategoryIcon = (categoriaId: string) => {
    const category = categories.find(c => c.id === categoriaId);
    return getIcon(category?.icon);
  };

  const getCategoryName = (categoriaId: string) => {
    return categories.find(c => c.id === categoriaId)?.nome || "Sem categoria";
  };

  const getStatusColor = (status: ShoppingItem["status"]) => {
    switch (status) {
      case "pendente": return "default";
      case "carrinho": return "secondary";
      case "comprado": return "outline";
      default: return "default";
    }
  };

  const getStatusLabel = (status: ShoppingItem["status"]) => {
    switch (status) {
      case "pendente": return "Pendente";
      case "carrinho": return "Carrinho";
      case "comprado": return "Comprado";
      default: return status;
    }
  };

  // Filtrar itens
  const filteredItems = items.filter(item => {
    if (statusFilter !== "todos" && item.status !== statusFilter) return false;
    if (categoryFilter && item.categoriaId !== categoryFilter) return false;
    return true;
  });

  // Ordenar itens
  const sortedItems = [...filteredItems].sort((a, b) => {
    let aValue: any, bValue: any;

    switch (sortBy) {
      case "nome":
        aValue = a.nome.toLowerCase();
        bValue = b.nome.toLowerCase();
        break;
      case "categoria":
        aValue = getCategoryName(a.categoriaId);
        bValue = getCategoryName(b.categoriaId);
        break;
      case "status":
        const statusOrder = { pendente: 0, carrinho: 1, comprado: 2 };
        aValue = statusOrder[a.status];
        bValue = statusOrder[b.status];
        break;
      case "preco":
        aValue = (a.preco || 0) * (a.quantidade || 0);
        bValue = (b.preco || 0) * (b.quantidade || 0);
        break;
      default:
        return 0;
    }

    if (aValue < bValue) return sortDirection === "asc" ? -1 : 1;
    if (aValue > bValue) return sortDirection === "asc" ? 1 : -1;
    return 0;
  });

  const handleSort = (column: SortBy) => {
    if (sortBy === column) {
      onSortChange(column, sortDirection === "asc" ? "desc" : "asc");
    } else {
      onSortChange(column, "asc");
    }
  };

  if (editingItem) {
    return (
      <ItemEditor
        categories={categories}
        editingItem={editingItem}
        onEditComplete={() => setEditingItem(null)}
      />
    );
  }

  if (sortedItems.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <p>Nenhum item encontrado com os filtros selecionados.</p>
      </div>
    );
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[50px]">Status</TableHead>
            <TableHead 
              className="cursor-pointer hover:bg-muted/50"
              onClick={() => handleSort("nome")}
            >
              Item {sortBy === "nome" && (sortDirection === "asc" ? "↑" : "↓")}
            </TableHead>
            <TableHead 
              className="cursor-pointer hover:bg-muted/50"
              onClick={() => handleSort("categoria")}
            >
              Categoria {sortBy === "categoria" && (sortDirection === "asc" ? "↑" : "↓")}
            </TableHead>
            <TableHead>Qtd/Unidade</TableHead>
            <TableHead className="text-right">Preço Unit.</TableHead>
            <TableHead 
              className="text-right cursor-pointer hover:bg-muted/50"
              onClick={() => handleSort("preco")}
            >
              Subtotal {sortBy === "preco" && (sortDirection === "asc" ? "↑" : "↓")}
            </TableHead>
            <TableHead className="text-right w-[100px]">Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedItems.map((item) => {
            const subtotal = (item.preco || 0) * (item.quantidade || 0);
            const hasDetails = item.dicaReceita || item.nutricao || item.marca || item.observacao;

            return (
              <TableRow key={item.id} className={item.status === "comprado" ? "opacity-60" : ""}>
                <TableCell>
                  <Checkbox
                    checked={item.status === "carrinho" || item.status === "comprado"}
                    onCheckedChange={() => toggleItemStatus(item.id)}
                  />
                </TableCell>

                <TableCell>
                  <div className="flex items-center gap-2">
                    {getCategoryIcon(item.categoriaId)}
                    <div>
                      <div className="font-medium">{item.nome}</div>
                      {hasDetails && (
                        <HoverCard>
                          <HoverCardTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-auto p-0 text-xs text-muted-foreground">
                              <Info className="h-3 w-3 mr-1" />
                              Detalhes
                            </Button>
                          </HoverCardTrigger>
                          <HoverCardContent className="w-80">
                            <div className="space-y-2">
                              {item.marca && (
                                <div>
                                  <strong>Marca:</strong> {item.marca}
                                </div>
                              )}
                              {item.dicaReceita && (
                                <div>
                                  <strong>Dica de Receita:</strong> {item.dicaReceita}
                                </div>
                              )}
                              {item.nutricao && (
                                <div>
                                  <strong>Informação Nutricional:</strong> {item.nutricao}
                                </div>
                              )}
                              {item.observacao && (
                                <div>
                                  <strong>Observações:</strong> {item.observacao}
                                </div>
                              )}
                            </div>
                          </HoverCardContent>
                        </HoverCard>
                      )}
                    </div>
                  </div>
                </TableCell>

                <TableCell>
                  <Badge variant="outline">
                    {getCategoryName(item.categoriaId)}
                  </Badge>
                </TableCell>

                <TableCell>
                  {item.quantidade} {item.unidade}
                </TableCell>

                <TableCell className="text-right">
                  {item.preco ? (
                    item.preco.toLocaleString("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    })
                  ) : (
                    <span className="text-muted-foreground">-</span>
                  )}
                </TableCell>

                <TableCell className="text-right font-medium">
                  {subtotal > 0 ? (
                    subtotal.toLocaleString("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    })
                  ) : (
                    <span className="text-muted-foreground">-</span>
                  )}
                </TableCell>

                <TableCell className="text-right">
                  <div className="flex gap-1 justify-end">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEditingItem(item)}
                      className="h-8 w-8 p-0"
                    >
                      <Edit2 className="h-3 w-3" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeItem(item.id)}
                      className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}