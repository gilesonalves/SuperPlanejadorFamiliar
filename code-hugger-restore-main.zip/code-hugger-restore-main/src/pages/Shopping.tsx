import { ShoppingLayout } from "@/components/shopping/ShoppingLayout";

export default function Shopping() {
  return <ShoppingLayout />;
}