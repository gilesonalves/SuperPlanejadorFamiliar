import type { ShoppingState, ShoppingList } from "./types";
import { defaultCategories, sampleItems } from "./seed";

const KEY = "sp_shopping_v1";

export function loadShopping(): ShoppingState {
  try {
    const stored = localStorage.getItem(KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (error) {
    console.warn("Erro ao carregar lista de compras:", error);
  }
  
  // Seed inicial
  const firstList: ShoppingList = {
    id: crypto.randomUUID(),
    nome: "Minha Lista",
    categorias: defaultCategories,
    itens: sampleItems.map(item => ({
      id: crypto.randomUUID(),
      status: "pendente" as const,
      ...item
    } as any)),
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  
  return { 
    listas: [firstList], 
    listaAtivaId: firstList.id, 
    plan: "free" 
  };
}

export function saveShopping(state: ShoppingState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch (error) {
    console.error("Erro ao salvar lista de compras:", error);
  }
}

// Limites do plano Free
export const FREE_LIMITS = { 
  maxLists: 1, 
  maxItems: 100 
};

export function canCreateList(state: ShoppingState): boolean {
  return state.plan === "pro" || state.listas.filter(l => !l.arquivada).length < FREE_LIMITS.maxLists;
}

export function canAddItem(state: ShoppingState): boolean {
  const total = state.listas.reduce((acc, lista) => 
    acc + (lista.arquivada ? 0 : lista.itens.length), 0
  );
  return state.plan === "pro" || total < FREE_LIMITS.maxItems;
}

export function getTotalItems(state: ShoppingState): number {
  return state.listas.reduce((acc, lista) => 
    acc + (lista.arquivada ? 0 : lista.itens.length), 0
  );
}